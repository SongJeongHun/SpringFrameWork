package com.example.demo.spring0406;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {
    @Bean
    public OperatorBean operatorBean(){
        OperatorBean op = new MinusOp();
        op.setOperand1(op1());
        op.setOperand2(op2());
        return op;
    }
    @Bean
    public Operand op1(){
        Operand o1 = new Operand();
        o1.setValue(10);
        return o1;
    }
    @Bean
    public Operand op2(){
        Operand o2 = new Operand();
        o2.setValue(20);
        return o2;
    }
}

package com.example.demo.spring0406;

public interface OperatorBean {
    int calc();
    public void setOperand1(Operand operand);
    public void setOperand2(Operand operand);

}

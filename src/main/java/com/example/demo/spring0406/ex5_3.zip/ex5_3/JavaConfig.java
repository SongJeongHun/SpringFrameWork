package com.example.demo.spring0406.ex5_2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class JavaConfig {

    @Bean
    @Scope("prototype")
    public OperatorBean operatorBean(){
        OperatorBean op = new MinusOp();
        return op;
    }
    @Bean
    @Scope("prototype")
    public
    Operand op1(){
        Operand o1 = new Operand();
        o1.setValue(10);
        return o1;
    }
    @Bean
    @Scope("prototype")
    public Operand op2(){
        Operand o2 = new Operand();
        o2.setValue(20);
        return o2;
    }
}

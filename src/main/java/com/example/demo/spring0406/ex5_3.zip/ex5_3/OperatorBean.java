package com.example.demo.spring0406.ex5_2;

public interface OperatorBean {
    int calc();
    public void setOperand1(Operand operand);
    public void setOperand2(Operand operand);

}
